// Simple AI placeholders: choose random playable card or draw
import { getPublicGameState } from "./gameLogic.js";

export function pickMoveForBot(roomCode, playerId) {
  const state = getPublicGameState(roomCode);
  // frontend will handle bots; this is placeholder
  return { action: "pass" };
}