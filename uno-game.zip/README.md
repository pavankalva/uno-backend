# UNO Game - Combined Backend + Minimal Frontend (Sample)

## Quick start

1. Extract the ZIP.
2. In the project root:
```
npm install
npm start
```
3. Open `http://localhost:3000` in your browser.

This is a starter sample:
- Full deck generation and basic UNO mechanics implemented on the server.
- Minimal frontend (served from `/public`) for quick testing.
- Socket.io real-time hooks provided; frontend demonstrates creating/joining rooms and starting games.
- Replace or add card images in `/public/assets` and customize UI as you like.

## Notes
- This sample uses in-memory storage. Restarting the server resets rooms and games.
- For deployment, push this repo to GitHub and connect to Render (or other Node host).